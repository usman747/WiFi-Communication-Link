# Contact Form Example
Simple contact form example for Django 2.0 that uses Django-Crispy-Forms, Bootstrap 4.0, and FontAwesome.

Make sure to install dependencies before trying to use.
You must put your email information in settings.py for it to work. 

Screenshot:
![](https://github.com/peterkaplan/Django2.0-Contact-Form/blob/master/screenshot.png)
